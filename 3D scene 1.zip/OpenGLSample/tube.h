#pragma once
#include "staticMesh3D.h"

namespace static_meshes_3D {

	/**
	* Tube static mesh with given radius, number of slices and height.
	*/
	class Tube : public StaticMesh3D
	{
	public:
		Tube(float radius, int numSlices, float height,
			bool withPositions = true, bool withTextureCoordinates = true, bool withNormals = true);

		void render() const override;
		void renderPoints() const override;

		/**
		 * Gets Tube radius.
		 */
		float getRadius() const;

		/**
		 * Gets number of Tube slices.
		 */
		int getSlices() const;

		/**
		 * Gets Tube height.
		 */
		float getHeight() const;

	private:
		float _radius; // Tube radius (distance from the center of cylinder to surface)
		int _numSlices; // Number of Tube slices
		float _height; // Height of the Tube

		int _numVerticesSide; // How many vertices to render side of the Tube
		int _numVerticesTopBottom; // How many vertices to render top / bottom of the Tube
		int _numVerticesTotal; // Just a sum of both numbers above

		void initializeData() override;
	};

} // namespace static_meshes_3D